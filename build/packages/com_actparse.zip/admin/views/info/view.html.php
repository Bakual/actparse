<?php
/* Thomas Hunziker - www.bakual.ch - Januar 2010 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );

/**
 * HTML View class for the actparse Admin Component
 */
class ActparseViewinfo extends JView
{
	function display($tpl = null)
	{
		parent::display($tpl);
	}	

}
